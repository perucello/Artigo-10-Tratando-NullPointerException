package npe_scripts;

public class NPE_01_null_OK {
    String teste;       

    public static void main(String[] args) {
        
        NPE_01_null_OK npe = new NPE_01_null_OK();
        System.out.println(npe.teste); //nesse momento retorna NULL 
        
    }
}
