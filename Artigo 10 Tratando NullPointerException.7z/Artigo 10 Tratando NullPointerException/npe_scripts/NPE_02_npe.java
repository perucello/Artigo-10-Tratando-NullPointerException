package npe_scripts;

public class NPE_02_npe {
    String teste;      

    public static void main(String[] args) {
        
        NPE_02_npe npe = new NPE_02_npe();
        System.out.println(npe.teste.toUpperCase()); //nesse momento estoura NullPointer, pois o Objeto nao foi informado!       
    }
}
