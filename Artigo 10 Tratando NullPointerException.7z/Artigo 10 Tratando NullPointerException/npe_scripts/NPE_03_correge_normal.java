package npe_scripts;

public class NPE_03_correge_normal {
    String teste;     

    public static void main(String[] args) {    

        NPE_03_correge_normal npe = new NPE_03_correge_normal();
                
//Nesse caso, estamos setando nosso Sistema para que o objeto "teste" possa ser diferente de null
// o que é ruim nesse ponto, é se tivessemos varios objetos, teriamos que tratar varios "ifs" e 
//teriamos uma serie de encadeamento
        if (npe.teste != null ) {        
        System.out.println(npe.teste.toUpperCase()); // nao retorna nada            
        }
    }
}
