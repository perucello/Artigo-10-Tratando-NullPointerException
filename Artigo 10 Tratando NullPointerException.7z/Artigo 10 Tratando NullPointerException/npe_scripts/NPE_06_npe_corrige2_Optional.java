package npe_scripts;
import java.util.Optional;
public class NPE_06_npe_corrige2_Optional {
    String teste;        
    public static void main(String[] args) {        
        NPE_06_npe_corrige2_Optional npe = new NPE_06_npe_corrige2_Optional();        
        //Nessa caso, estamos usando um artefato do pacote de utilitarios do Java chamado Optional
        //Nesse caso, estamos informando que a String "teste" é ofNullable de uma maneira diferente.
        Optional<String> opt = Optional.ofNullable(npe.teste);
        System.out.println(opt);        
//Nesse caso, estamos setando nosso Sistema para que o objeto "nome" possa ser diferente de null
// o que é ruim nesse ponto, é se tivessemos varios objetos, teriamos que tratar varios "ifs" e teriamos uma serie de encadeamento
        if (npe.teste != null ) {        
        System.out.println(npe.teste.toUpperCase()); // nao retorna nada            
        }
    }
}
