package npe_scripts;
import java.util.Optional;
public class NPE_08_npe_com_OrElse_Optional {
    String teste;        
    public static void main(String[] args) {        
        NPE_08_npe_com_OrElse_Optional npe = new NPE_08_npe_com_OrElse_Optional();
               Optional<String> opt = Optional.empty();
        System.out.println(opt);        
        //Mapeando valores
        System.out.println(opt.orElse("vazio"));       
   }
}

