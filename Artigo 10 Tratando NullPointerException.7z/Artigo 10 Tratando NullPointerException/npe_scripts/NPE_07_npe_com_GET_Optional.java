package npe_scripts;
import java.util.Optional;
public class NPE_07_npe_com_GET_Optional {
    String teste;        
    public static void main(String[] args) {        
        NPE_07_npe_com_GET_Optional npe = new NPE_07_npe_com_GET_Optional();        
        //estoura NoSuchException       
        Optional<String> opt = Optional.ofNullable(npe.teste);
        System.out.println(opt);
        //Mapeando valores
        //nesse caso, estamos verificando se ja alfo em nosso "opt"
        System.out.println(opt.get());
        if(opt.isPresent()); 
   }
}

