public class npe{
    public static void main(String[] args) {
        
        Teste teste = new Teste( "10" );
        System.out.println ("Testando Sout teste: " 
                    + teste.getValor().length() );
        Teste teste2 = new Teste(null);
        if (teste2.getValor() != null) {
            System.out.println ("Testando Sout teste2: " 
                    + teste2.getValor().length() );
        } else {
            System.out.println("considera teste2 como 'null' ");            
        }
  }
}