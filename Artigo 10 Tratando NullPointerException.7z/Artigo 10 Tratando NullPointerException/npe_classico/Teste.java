public class Teste{
 
    private String texto = null;

    public Teste ( String nova) {
         this.texto = nova;
    }

   public String getValor( ) {
         return this.texto;
   }
}